var siteScript = {} || siteScript;

siteScript = {
	init: function() {

		// object variables	
		var Vars = {

		}

		this.tabNav({	element: '.mod-highlight',tag :'a',	classname:'active',	target: '.tab-content'});
		this.closebtn({element:'.btn-close'});

	},

	tabNav: function(obj) {
		$('body').on('click',obj.element+' '+obj.tag,function(e){
			var _this = $(this),
					targetElement = _this.attr('href'),
					parentTab = _this.closest(obj.element);

			// remove existing active classname from tab content
			parentTab.siblings(obj.target).removeClass(obj.classname);
			parentTab.siblings(targetElement).addClass(obj.classname);

			// update classname for navigation items
			parentTab.find(obj.tag).removeClass(obj.classname);
			_this.addClass(obj.classname);
			//alert(obj.element);
			if ($(obj.element).hasClass('cta')) {
				//alert('This is selected!');
      	//return false
    	}
    	else {
				e.preventDefault();
				//alert(e)
			}
			//e.preventDefault();
		})
	},
	closebtn:function(obj){
		$('body').on('click',obj.element,function(){
			var dataTarget = $(this).data('target');
			$(dataTarget).slideUp();
		})
	}
}

// document ready
$(function() {
	siteScript.init();
})
var windowWidth = $(window).width();
function mobiledetect(){
	if( windowWidth <= 480 ) { 
		$("#navbar-collapse-1 ul.nav.navbar-nav").prepend('<li><a href="/user/messages"><span class="tab">Message Center</span></a></li>');
	}
	
	//$('.collapse').collapse();
 	//$('.mod-details.infocontent h2').attr('data-toggle', '');
}
$(window).load(function(){
$(document).ready(function ($) {
	mobiledetect();
	$('.dropdown').hover(function(){ 
		$('.dropdown-toggle', this).trigger('click'); 
	});
	$('#nav-expander').on('click',function(e){
		e.preventDefault();
		$('body').toggleClass('nav-expanded');
	  var effect = 'slide';
		// Set the options for the effect type chosen
		var options = { direction: 'left' };
		// Set the duration (default: 400 milliseconds)
		var duration = 50000;
		//$(".slidingDiv").toggle("slide");
		//$("#navbar-collapse-1").toggle(effect, options, duration);
	});
	$('.mod-details.infocontent h2').on('click',function(e){
		//$('.collapse').collapse();
		
	}, function() {
		//$(this).css({"background":"red"});
    $('#box').imagesLoaded(function(){
			$('#box').isotope({
			    itemSelector : '.post-box',
			    resizable: true
			});
	});
});
	// $('#nav-close').on('click',function(e){
	// 	e.preventDefault();
	// 	$('body').removeClass('nav-expanded');
	// });
	// 
	// $('#box').imagesLoaded(function(){
	// 	$('#box').masonry({
	// 		itemSelector : '.post-box',
	// 		//columnWidth: '.post-box'
	// 	});
	// });
	// 
// 	var $container = $('#box').masonry();
// // layout Masonry again after all images have loaded
// 	$container.imagesLoaded( function() {
// 	  $container.masonry({
// 			itemSelector : '.post-box',
// 			columnWidth: '.post-box'
// 		});
// 	});

	// var container = document.querySelector('#box');
	// var msnry = new Masonry( container, {
 //  columnWidth: 300,
 //  itemSelector: '.post-box'
	// });
	// 
	// var $container = $('#box').width();
	// $('#box').masonry({
 //      itemSelector: '.post-box',
 //      //columnWidth: $container / 5,
 //      // set columnWidth a fraction of the container width
 //      columnWidth: function( containerWidth ) {
 //        return containerWidth / 3;
 //      },
 //      isAnimated: true,
 //      fitRows:true
 //    });
	$('#box').imagesLoaded(function(){
		$('#box').isotope({
		    itemSelector : '.post-box',
		    resizable: true
		});
	});

});
});
$( window ).resize(function() {
	//alert('hi');
	mobiledetect();
});
